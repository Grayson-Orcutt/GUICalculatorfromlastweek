﻿using System;

public interface ISolve
{
    public void Accumulate(string S);
    public void Clear();
    public double Solve(string S);
}