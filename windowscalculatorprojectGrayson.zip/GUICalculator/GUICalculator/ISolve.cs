﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GUICalculator
{
    public interface ISolve
    {
        void Accumulate(string S);
        void Clear();
        double Solve(string S);
    }
}
