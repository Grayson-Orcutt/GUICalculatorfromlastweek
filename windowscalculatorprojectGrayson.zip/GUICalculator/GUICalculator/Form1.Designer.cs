﻿namespace GUICalculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.allclear = new System.Windows.Forms.Button();
            this.negativebutton = new System.Windows.Forms.Button();
            this.perscentbutton = new System.Windows.Forms.Button();
            this.dividebutton = new System.Windows.Forms.Button();
            this.onebutton = new System.Windows.Forms.Button();
            this.fourbutton = new System.Windows.Forms.Button();
            this.sevenbutton = new System.Windows.Forms.Button();
            this.twobutton = new System.Windows.Forms.Button();
            this.threebutton = new System.Windows.Forms.Button();
            this.fivebutton = new System.Windows.Forms.Button();
            this.sixbutton = new System.Windows.Forms.Button();
            this.eightbutton = new System.Windows.Forms.Button();
            this.ninebutton = new System.Windows.Forms.Button();
            this.zerobutton = new System.Windows.Forms.Button();
            this.decimalbutton = new System.Windows.Forms.Button();
            this.addbutton = new System.Windows.Forms.Button();
            this.subtractbutton = new System.Windows.Forms.Button();
            this.multiplybutton = new System.Windows.Forms.Button();
            this.equalsbutton = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // allclear
            // 
            this.allclear.Location = new System.Drawing.Point(79, 139);
            this.allclear.Name = "allclear";
            this.allclear.Size = new System.Drawing.Size(75, 23);
            this.allclear.TabIndex = 0;
            this.allclear.Text = "AC";
            this.allclear.UseVisualStyleBackColor = true;
            this.allclear.Click += new System.EventHandler(this.button1_Click);
            // 
            // negativebutton
            // 
            this.negativebutton.Location = new System.Drawing.Point(240, 139);
            this.negativebutton.Name = "negativebutton";
            this.negativebutton.Size = new System.Drawing.Size(75, 23);
            this.negativebutton.TabIndex = 1;
            this.negativebutton.Text = "+/-";
            this.negativebutton.UseVisualStyleBackColor = true;
            this.negativebutton.Click += new System.EventHandler(this.negativebutton_Click);
            // 
            // perscentbutton
            // 
            this.perscentbutton.Location = new System.Drawing.Point(431, 138);
            this.perscentbutton.Name = "perscentbutton";
            this.perscentbutton.Size = new System.Drawing.Size(75, 23);
            this.perscentbutton.TabIndex = 2;
            this.perscentbutton.Text = "%";
            this.perscentbutton.UseVisualStyleBackColor = true;
            this.perscentbutton.Click += new System.EventHandler(this.button3_Click);
            // 
            // dividebutton
            // 
            this.dividebutton.Location = new System.Drawing.Point(634, 138);
            this.dividebutton.Name = "dividebutton";
            this.dividebutton.Size = new System.Drawing.Size(75, 23);
            this.dividebutton.TabIndex = 3;
            this.dividebutton.Text = "/";
            this.dividebutton.UseVisualStyleBackColor = true;
            this.dividebutton.Click += new System.EventHandler(this.dividebutton_Click);
            // 
            // onebutton
            // 
            this.onebutton.Location = new System.Drawing.Point(79, 199);
            this.onebutton.Name = "onebutton";
            this.onebutton.Size = new System.Drawing.Size(75, 23);
            this.onebutton.TabIndex = 4;
            this.onebutton.Text = "1";
            this.onebutton.UseVisualStyleBackColor = true;
            this.onebutton.Click += new System.EventHandler(this.onebutton_Click);
            // 
            // fourbutton
            // 
            this.fourbutton.Location = new System.Drawing.Point(79, 256);
            this.fourbutton.Name = "fourbutton";
            this.fourbutton.Size = new System.Drawing.Size(75, 23);
            this.fourbutton.TabIndex = 5;
            this.fourbutton.Text = "4";
            this.fourbutton.UseVisualStyleBackColor = true;
            this.fourbutton.Click += new System.EventHandler(this.fourbutton_Click);
            // 
            // sevenbutton
            // 
            this.sevenbutton.Location = new System.Drawing.Point(79, 319);
            this.sevenbutton.Name = "sevenbutton";
            this.sevenbutton.Size = new System.Drawing.Size(75, 23);
            this.sevenbutton.TabIndex = 6;
            this.sevenbutton.Text = "7";
            this.sevenbutton.UseVisualStyleBackColor = true;
            this.sevenbutton.Click += new System.EventHandler(this.sevenbutton_Click);
            // 
            // twobutton
            // 
            this.twobutton.Location = new System.Drawing.Point(240, 198);
            this.twobutton.Name = "twobutton";
            this.twobutton.Size = new System.Drawing.Size(75, 23);
            this.twobutton.TabIndex = 7;
            this.twobutton.Text = "2";
            this.twobutton.UseVisualStyleBackColor = true;
            this.twobutton.Click += new System.EventHandler(this.twobutton_Click);
            // 
            // threebutton
            // 
            this.threebutton.Location = new System.Drawing.Point(431, 198);
            this.threebutton.Name = "threebutton";
            this.threebutton.Size = new System.Drawing.Size(75, 23);
            this.threebutton.TabIndex = 8;
            this.threebutton.Text = "3";
            this.threebutton.UseVisualStyleBackColor = true;
            this.threebutton.Click += new System.EventHandler(this.threebutton_Click);
            // 
            // fivebutton
            // 
            this.fivebutton.Location = new System.Drawing.Point(240, 255);
            this.fivebutton.Name = "fivebutton";
            this.fivebutton.Size = new System.Drawing.Size(75, 23);
            this.fivebutton.TabIndex = 9;
            this.fivebutton.Text = "5";
            this.fivebutton.UseVisualStyleBackColor = true;
            this.fivebutton.Click += new System.EventHandler(this.fivebutton_Click);
            // 
            // sixbutton
            // 
            this.sixbutton.Location = new System.Drawing.Point(431, 255);
            this.sixbutton.Name = "sixbutton";
            this.sixbutton.Size = new System.Drawing.Size(75, 23);
            this.sixbutton.TabIndex = 10;
            this.sixbutton.Text = "6";
            this.sixbutton.UseVisualStyleBackColor = true;
            this.sixbutton.Click += new System.EventHandler(this.sixbutton_Click);
            // 
            // eightbutton
            // 
            this.eightbutton.Location = new System.Drawing.Point(240, 319);
            this.eightbutton.Name = "eightbutton";
            this.eightbutton.Size = new System.Drawing.Size(75, 23);
            this.eightbutton.TabIndex = 11;
            this.eightbutton.Text = "8";
            this.eightbutton.UseVisualStyleBackColor = true;
            this.eightbutton.Click += new System.EventHandler(this.button12_Click);
            // 
            // ninebutton
            // 
            this.ninebutton.Location = new System.Drawing.Point(431, 319);
            this.ninebutton.Name = "ninebutton";
            this.ninebutton.Size = new System.Drawing.Size(75, 23);
            this.ninebutton.TabIndex = 12;
            this.ninebutton.Text = "9";
            this.ninebutton.UseVisualStyleBackColor = true;
            this.ninebutton.Click += new System.EventHandler(this.ninebutton_Click);
            // 
            // zerobutton
            // 
            this.zerobutton.Location = new System.Drawing.Point(79, 371);
            this.zerobutton.Name = "zerobutton";
            this.zerobutton.Size = new System.Drawing.Size(236, 23);
            this.zerobutton.TabIndex = 13;
            this.zerobutton.Text = "0";
            this.zerobutton.UseVisualStyleBackColor = true;
            this.zerobutton.Click += new System.EventHandler(this.zerobutton_Click);
            // 
            // decimalbutton
            // 
            this.decimalbutton.Location = new System.Drawing.Point(431, 371);
            this.decimalbutton.Name = "decimalbutton";
            this.decimalbutton.Size = new System.Drawing.Size(75, 23);
            this.decimalbutton.TabIndex = 14;
            this.decimalbutton.Text = ".";
            this.decimalbutton.UseVisualStyleBackColor = true;
            this.decimalbutton.Click += new System.EventHandler(this.decimalbutton_Click);
            // 
            // addbutton
            // 
            this.addbutton.Location = new System.Drawing.Point(634, 199);
            this.addbutton.Name = "addbutton";
            this.addbutton.Size = new System.Drawing.Size(75, 23);
            this.addbutton.TabIndex = 15;
            this.addbutton.Text = "+";
            this.addbutton.UseVisualStyleBackColor = true;
            this.addbutton.Click += new System.EventHandler(this.addbutton_Click);
            // 
            // subtractbutton
            // 
            this.subtractbutton.Location = new System.Drawing.Point(634, 255);
            this.subtractbutton.Name = "subtractbutton";
            this.subtractbutton.Size = new System.Drawing.Size(75, 23);
            this.subtractbutton.TabIndex = 16;
            this.subtractbutton.Text = "-";
            this.subtractbutton.UseVisualStyleBackColor = true;
            this.subtractbutton.Click += new System.EventHandler(this.subtractbutton_Click);
            // 
            // multiplybutton
            // 
            this.multiplybutton.Location = new System.Drawing.Point(634, 319);
            this.multiplybutton.Name = "multiplybutton";
            this.multiplybutton.Size = new System.Drawing.Size(75, 23);
            this.multiplybutton.TabIndex = 17;
            this.multiplybutton.Text = "X";
            this.multiplybutton.UseVisualStyleBackColor = true;
            this.multiplybutton.Click += new System.EventHandler(this.multiplybutton_Click);
            // 
            // equalsbutton
            // 
            this.equalsbutton.Location = new System.Drawing.Point(634, 371);
            this.equalsbutton.Name = "equalsbutton";
            this.equalsbutton.Size = new System.Drawing.Size(75, 23);
            this.equalsbutton.TabIndex = 18;
            this.equalsbutton.Text = "=";
            this.equalsbutton.UseVisualStyleBackColor = true;
            this.equalsbutton.Click += new System.EventHandler(this.equalsbutton_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(79, 24);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.textBox1.Size = new System.Drawing.Size(630, 74);
            this.textBox1.TabIndex = 19;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.equalsbutton);
            this.Controls.Add(this.multiplybutton);
            this.Controls.Add(this.subtractbutton);
            this.Controls.Add(this.addbutton);
            this.Controls.Add(this.decimalbutton);
            this.Controls.Add(this.zerobutton);
            this.Controls.Add(this.ninebutton);
            this.Controls.Add(this.eightbutton);
            this.Controls.Add(this.sixbutton);
            this.Controls.Add(this.fivebutton);
            this.Controls.Add(this.threebutton);
            this.Controls.Add(this.twobutton);
            this.Controls.Add(this.sevenbutton);
            this.Controls.Add(this.fourbutton);
            this.Controls.Add(this.onebutton);
            this.Controls.Add(this.dividebutton);
            this.Controls.Add(this.perscentbutton);
            this.Controls.Add(this.negativebutton);
            this.Controls.Add(this.allclear);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button allclear;
        private System.Windows.Forms.Button negativebutton;
        private System.Windows.Forms.Button perscentbutton;
        private System.Windows.Forms.Button dividebutton;
        private System.Windows.Forms.Button onebutton;
        private System.Windows.Forms.Button fourbutton;
        private System.Windows.Forms.Button sevenbutton;
        private System.Windows.Forms.Button twobutton;
        private System.Windows.Forms.Button threebutton;
        private System.Windows.Forms.Button fivebutton;
        private System.Windows.Forms.Button sixbutton;
        private System.Windows.Forms.Button eightbutton;
        private System.Windows.Forms.Button ninebutton;
        private System.Windows.Forms.Button zerobutton;
        private System.Windows.Forms.Button decimalbutton;
        private System.Windows.Forms.Button addbutton;
        private System.Windows.Forms.Button subtractbutton;
        private System.Windows.Forms.Button multiplybutton;
        private System.Windows.Forms.Button equalsbutton;
        private System.Windows.Forms.TextBox textBox1;
    }
}

