﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GUICalculator
{
    class Solver
    {
        public string input;
        public Solver()
        {
            input = "";
        }

        public void Accumulate(string S)
        {
            input += Convert.ToChar(S);
            Console.WriteLine("input is {0}", input);
        }
        public void Clear()
        {
            input = "";
            Console.WriteLine("All Clear");
        }
        public double Solve(string S)
        {
            string[] newlist = new string[20] { "n", "n", "n", "n", "n", "n", "n", "n", "n", "n", "n", "n", "n", "n", "n", "n", "n", "n", "n", "n"};
            bool[] tomakenegative = new bool[20] { false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false };


            // Putting the string in an array

            int count = 0;
            for (int i = 0; i < S.Length; i++)
            {
                if (S[i] == '+' || S[i] == '/' || S[i] == '*' || S[i] == '%')
                {
                    if (i != 0 || S[i] != '%')
                    {
                        count++;
                    }
                    newlist[count] = Convert.ToString(S[i]);
                    count++;
                }
                else if (S[i] == '-')
                {
                    if(i == 0)
                    {
                        tomakenegative[i] = true;
                    }
                    else if (S[i-1] == '+' || S[i-1] == '/' || S[i-1] == '*' || S[i-1] == '%' || S[i-1] == '-' || i == 0)
                    {
                        tomakenegative[i] = true;
                    }
                    else
                    {
                        count++;
                        newlist[count] = "-";
                        count++;
                    }
                }
                else
                {
                    if (newlist[count] == "n")
                    {
                        newlist[count] = Convert.ToString(S[i]);
                    }
                    else
                        newlist[count] += Convert.ToString(S[i]);
                }
            }

            // Making the negative things negative.

            for(int i = 0; i < S.Length; i++)
            {
                if(tomakenegative[i] == true)
                {
                    newlist[i] = Convert.ToString(Convert.ToDouble(newlist[i]) * -1);
                }
            }

            // Alright it's time to actually math

            //Also! I moved everything to a new array so I could have separate complete numbers. If something in the array equals s or n, it's skipped in checks.

            // Multiplication
            for (int i = 0; i < 20; i++)
            {
                if (newlist[i] == "*")
                {
                    int left = i-1;
                    int right = i+1;
                    while(newlist[left] == "s")
                    {
                        left--;
                    }
                    while(newlist[right] == "s")
                    {
                        right++;
                    }
                    double calculate1 = Convert.ToDouble(newlist[left]);
                    double calculate2 = Convert.ToDouble(newlist[right]);
                    newlist[left] = Convert.ToString(calculate1 * calculate2);
                    newlist[i] = "s";
                    newlist[right] = "s";
                }
            }

            // Division
            for (int i = 0; i < 20; i++)
            {
                if (newlist[i] == "/")
                {
                    int left = i - 1;
                    int right = i + 1;
                    while (newlist[left] == "s")
                    {
                        left--;
                    }
                    while (newlist[right] == "s")
                    {
                        right++;
                    }
                    double calculate1 = Convert.ToDouble(newlist[left]);
                    double calculate2 = Convert.ToDouble(newlist[right]);
                    newlist[left] = Convert.ToString(calculate1 / calculate2);
                    newlist[i] = "s";
                    newlist[right] = "s";
                }
            }

            // %
            for (int i = 0; i < 20; i++)
            {
                if (newlist[i] == "%")
                {
                    int left = i - 1;
                    int right = i + 1;
                    while (newlist[right] == "s")
                    {
                        right++;
                    }
                    double calculate1 = Convert.ToDouble(newlist[right]);
                    newlist[i] = Convert.ToString(calculate1 /100);
                    newlist[right] = "s";
                }
            }

            // Addition
            for (int i = 0; i < 20; i++)
            {
                if (newlist[i] == "+")
                {
                    int left = i - 1;
                    int right = i + 1;
                    while (newlist[left] == "s")
                    {
                        left--;
                    }
                    while (newlist[right] == "s")
                    {
                        right++;
                    }
                    double calculate1 = Convert.ToDouble(newlist[left]);
                    double calculate2 = Convert.ToDouble(newlist[right]);
                    newlist[left] = Convert.ToString(calculate1 + calculate2);
                    newlist[i] = "s";
                    newlist[right] = "s";
                }
            }

            // Division
            for (int i = 0; i < 20; i++)
            {
                if (newlist[i] == "-")
                {
                    int left = i - 1;
                    int right = i + 1;
                    while (newlist[left] == "s")
                    {
                        left--;
                    }
                    while (newlist[right] == "s")
                    {
                        right++;
                    }
                    double calculate1 = Convert.ToDouble(newlist[left]);
                    double calculate2 = Convert.ToDouble(newlist[right]);
                    newlist[left] = Convert.ToString(calculate1 - calculate2);
                    newlist[i] = "s";
                    newlist[right] = "s";
                }
            }



            // Outputing
            return (Convert.ToDouble(newlist[0]));
        }
    }
}
