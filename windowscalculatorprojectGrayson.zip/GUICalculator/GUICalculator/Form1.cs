﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GUICalculator
{
    public partial class Form1 : Form
    {

        Solver Calculator;
        public Form1()
        {
            InitializeComponent();
            Calculator = new Solver();
            textBox1.Text = "" + Environment.NewLine + "--------------";
            //textBox1.Text = Convert.ToString(Calculator.Solve("2*3+5+-6/3+9*8"));
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //ALL CLEAR
            Calculator.Clear();
            textBox1.Text = Calculator.input + Environment.NewLine + "--------------";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Calculator.Accumulate("%");
            textBox1.Text = Calculator.input + Environment.NewLine + "--------------";
        }

        private void button12_Click(object sender, EventArgs e)
        {
            Calculator.Accumulate("8");
            textBox1.Text = Calculator.input + Environment.NewLine + "--------------";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void equalsbutton_Click(object sender, EventArgs e)
        {
            if (Calculator.Solve(Calculator.input) < 0)
                textBox1.Text = Calculator.input + Environment.NewLine + "--------------" + Environment.NewLine + (Calculator.Solve(Calculator.input) * -1) + "-";
            else
                textBox1.Text = Calculator.input + Environment.NewLine + "--------------" + Environment.NewLine + Calculator.Solve(Calculator.input);
        }

        private void negativebutton_Click(object sender, EventArgs e)
        {
            Calculator.Accumulate("-");
            textBox1.Text = Calculator.input + Environment.NewLine + "--------------";
        }

        private void dividebutton_Click(object sender, EventArgs e)
        {
            Calculator.Accumulate("/");
            textBox1.Text = Calculator.input + Environment.NewLine + "--------------";
        }

        private void onebutton_Click(object sender, EventArgs e)
        {
            Calculator.Accumulate("1");
            textBox1.Text = Calculator.input + Environment.NewLine + "--------------";
        }

        private void twobutton_Click(object sender, EventArgs e)
        {
            Calculator.Accumulate("2");
            textBox1.Text = Calculator.input + Environment.NewLine + "--------------";
        }

        private void threebutton_Click(object sender, EventArgs e)
        {
            Calculator.Accumulate("3");
            textBox1.Text = Calculator.input + Environment.NewLine + "--------------";
        }

        private void addbutton_Click(object sender, EventArgs e)
        {
            Calculator.Accumulate("+");
            textBox1.Text = Calculator.input + Environment.NewLine + "--------------";
        }

        private void fourbutton_Click(object sender, EventArgs e)
        {
            Calculator.Accumulate("4");
            textBox1.Text = Calculator.input + Environment.NewLine + "--------------";
        }

        private void fivebutton_Click(object sender, EventArgs e)
        {
            Calculator.Accumulate("5");
            textBox1.Text = Calculator.input + Environment.NewLine + "--------------";
        }

        private void sixbutton_Click(object sender, EventArgs e)
        {
            Calculator.Accumulate("6");
            textBox1.Text = Calculator.input + Environment.NewLine + "--------------";
        }

        private void subtractbutton_Click(object sender, EventArgs e)
        {
            Calculator.Accumulate("-");
            textBox1.Text = Calculator.input + Environment.NewLine + "--------------";
        }

        private void sevenbutton_Click(object sender, EventArgs e)
        {
            Calculator.Accumulate("7");
            textBox1.Text = Calculator.input + Environment.NewLine + "--------------";
        }

        private void ninebutton_Click(object sender, EventArgs e)
        {
            Calculator.Accumulate("9");
            textBox1.Text = Calculator.input + Environment.NewLine + "--------------";
        }

        private void multiplybutton_Click(object sender, EventArgs e)
        {
            Calculator.Accumulate("*");
            textBox1.Text = Calculator.input + Environment.NewLine + "--------------";
        }

        private void zerobutton_Click(object sender, EventArgs e)
        {
            Calculator.Accumulate("0");
            textBox1.Text = Calculator.input + Environment.NewLine + "--------------";
        }

        private void decimalbutton_Click(object sender, EventArgs e)
        {
            Calculator.Accumulate(".");
            textBox1.Text = Calculator.input + Environment.NewLine + "--------------";
        }
    }
}
